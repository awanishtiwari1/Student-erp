import com.sun.jdi.event.ExceptionEvent;
import java.sql.*;
import java.util.Scanner;
//A Software completely impelemented n java of Student ERP system with database connection
// A new student can albe to register by entering his/her credentials and if the username , password etc and save to it database for login purpose .
//An old user can login through his/her credentials and utilise whatever the services are prvided .
public class Student_ERP {
//Declaring all variables as static because they use static functionality and can be used anywhere in the whole class
    static Connection c;
   static Statement st;
   static ResultSet rs;
   static Statement st2;
// Method login for Logging in the old user by checking their credentials
   public static void  login() {
       //PreparedStatement ps,ps2;
       Scanner s = new Scanner(System.in);
       System.out.println("Enter your rollno to login");
       String r = s.nextLine();
       System.out.println("Enter your password");
       String p = s.nextLine();
//After entering roll no and password Check that whether it exists or not ?
       //If username and password matches show the partiular profile to the student
       //If password does not matches display enter correct password
       try {
           rs = st.executeQuery("SELECT * from student WHERE  rollno = '" + r + "'");
           while (rs.next()) {
               String s1 = rs.getString("rollno");
               String p1 = rs.getString("password");
               if ((s1.equals(r)) && (p1.equals(p))) {
                   System.out.println("You have login succesfully ");
                   System.out.println("Choose your options ");
                   Scanner sc = new Scanner(System.in);
                   //After a successfull login show the dashboard to the student
                   while (true) {
                       System.out.println("\t\t\t\t1->Your Attendance\t\t2->Your marks\n\n\t\t\t\t3->Your Internships \t 4->Change Password\n\t\t\t\t\t\t5->Exit ");
                       int c = sc.nextInt();
                       if (c == 1) {
                           //Show attendence of the student
                           rs = st.executeQuery("select * from cell where rollno = '" + s1 + "'");
                           while (rs.next()) {
                               System.out.print("Your Academic attendance is\t");
                               //Showing the attendance of the student by fetching it from database
                               System.out.println(rs.getString("attendance"));
                           }
                       }
                       if (c == 2) {
                           //Show marks  of the student2
                           rs = st.executeQuery("select * from cell where rollno = '" + s1 + "'");
                           while (rs.next()) {
                               System.out.print("Your overall acedemic % is:\t");
                               System.out.println(rs.getString("marks"));
                           }
                       }
                       if (c == 3) {
                           //Show Internships of the student
                           //System.out.println("Currently there is no any internship available");
                           rs = st.executeQuery("select internships from cell where rollno = '" + s1 + "'");
                           while (rs.next()) {
                               System.out.println(rs.getString("internships"));
                           }
                       }
                       if (c == 4) {
                           //change the existing password
                           rs = st.executeQuery("select * from student where rollno = '" + s1 + "'");
                           System.out.println("Enter your old password please");
                           String op = sc.next();
                           while (rs.next()) {
                               String t1 = rs.getString("password");
                               //If old password matches with entered password then input the new password from student
                               if (op.equals(p1)) {
                                   System.out.println("Enter your new password");
                                   String np = sc.next();
                                   try {
                                       //After entering the new password update the old password with the previous one
                                       int a = st.executeUpdate("update student set password = '"+np+"' where password = '"+p1+"'");
                                       if (a == 1) {
                                           //Show acknowledgement the student that Password Changed successfully
                                           System.out.println("Password changed Successfully");
                                           //Do not any extra warning related to it if it got successfully updated
                                           rs.clearWarnings();
                                       }
                                   } catch (Exception e) {
                                       System.out.println("You Can login now with new password");
                                   }
                               }
                               //If password does not matches
                               else {
                                   System.out.println("Your password does not match with previous password");
                               }
                           }
                       }
                       if(c==5)
                       {
                           System.exit(0);
                       }
                   }
                   }
                else
                   {
                       System.out.println("Wrong Password , Please login with with correct password");
                       login();
                   }
               }

//If connection fails to connect through the table or row,column
           } catch(SQLException e)
           {
               System.out.println("login Please");
           }
       }
//Registration of new Student
   public static void register()
   {
       System.out.println();
       PreparedStatement ps ;
       try {
           //Taking the input of credentials
           System.out.println("Enter the details of the students");
           System.out.println("name,rollno,phone , email , gender, password ");
           String name , email , gender ;
           String rollno , phone, pass ;
           Scanner sc = new Scanner(System.in);
           name = sc.nextLine();
           rollno = sc.nextLine();
           phone = sc.nextLine();
           email = sc.nextLine();
           gender = sc.nextLine();
           pass = sc.next();
            //prepareStatement to prepare a statement with connection which we have insert into databse
            ps = c.prepareStatement("insert into student values('"+name+"' , '"+rollno+"','"+phone+"' ,'"+email+"' ,'"+gender+"','"+pass+"')");
           ps.execute();
           //If user able to complete registration successfully
           if(ps.execute())
           {
               System.out.println("Registered Successfully ");
               System.out.println("Would you like to login");
               System.out.println("press 1 for yes , press 0 to exit");
               int c = sc.nextInt();
               if(c==1)
               {
                   login();
               }
               if(c==0)
               {
                   System.exit(0);
                   //Will exit from the program
               }
                else
               {
                   System.out.println("please choose the correct choice ");
               }
           }
       } catch (SQLException e)
       {
           System.out.println("You have been registered\nNow you can login");
       }
       System.exit(0);
   }
//Method for showing the profile of the student
   public static void showp(String s)
    {
        try
        {
            //This query will select all properties of the student of rollno given
            ResultSet rs = st.executeQuery("select * from student where rollno = '"+s+"'");
            while(rs.next())
            {
                System.out.println(rs.getString("name"));
            }
        }
        catch(Exception e )
        {
            System.out.println(e);
        }
    }
    public static void main(String[] args) throws SQLException {
        while (true) {
            //The overall statement is surrounded with try catch block because at run time it might be possible that server is not on or and other issue
            //then that can be managed by this program and saves from program crashes
            try {
                //Will try to connect to the database
                Class.forName("com.mysql.cj.jdbc.Driver");
                c = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
                st = c.createStatement();
                System.out.println("\t\t\t\t\t\t\t\t\t\tWelcome to Student ERP System\t\t\t\t ");
                System.out.println("\t\t\t\t\t\t\t\t\t\tChoose options to know more \t\t\t\t ");
                System.out.println("\t\t\t\t\t\t\t\t\t\t1->Regiter \t\t2-> Login\n\t\t\t\t\t\t\t\t\t\t\t\t3->Exit ");
                Scanner sc = new Scanner(System.in);
                int choice = sc.nextInt();
                if (choice == 1) {
                    register();
                }
                if (choice == 2) {
                    login();
                    System.exit(0);
                }
                if(choice == 3)
                {
                    System.out.println("Exiting\nYou have exited\n ");
                    System.exit(0);
                }
                else {
                    System.out.println("Please choose the right one");
                    System.exit(0);
                }
            } catch (Exception e) {
                System.out.println(e);
            }

        }
    }
}
